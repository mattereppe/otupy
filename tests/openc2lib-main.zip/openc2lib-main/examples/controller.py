#!../.venv/bin/python3
# Example to use the OpenC2 library
#
import argparse
import logging
import sys
import openc2lib as oc2
from openc2lib.core.producer import Producer
from openc2lib.encoders.json import JSONEncoder
from openc2lib.transfers.http import HTTPTransfer
import openc2lib.profiles.slpf as slpf


#logging.basicConfig(filename='openc2.log',level=logging.DEBUG)
logging.basicConfig(stream=sys.stdout,level=logging.INFO)
logger = logging.getLogger('openc2producer')

# Instantiate a Producer parameter to send OpenC2 commands
producer = Producer("OpenC2_Producer",
                    JSONEncoder(),
                    HTTPTransfer("192.168.197.128",
                                 5000,
                                 endpoint="/.well-known/openc2"))

def create_openc2_command(action, target, args):
    """
    Create an OpenC2 command based on provided action, target, and args.
    """
    return Command(action, target, args), target, args

def main():
    logger.info("Creating Producer")
    # p = oc2.Producer("producer.example.net", JSONEncoder(), HTTPTransfer("127.0.0.1", 8080))
    #
    # pf = slpf.slpf({'hostname':'firewall', 'named_group':'firewalls', 'asset_id':'iptables'})
    #
    # arg = slpf.Args({'response_requested': oc2.ResponseType.complete})
    #
    # cmd = oc2.Command(oc2.Actions.query, oc2.Features(), actuator=pf)

    # Create the arguments parser
    parser = argparse.ArgumentParser(description="Send OpenC2 commands using a producer.")

    # Add arguments for each action
    parser.add_argument("action", choices=["allow", "deny", "query", "delete", "update"], help="Type of Action")
    parser.add_argument("target_type", choices=["ipv4_net", "ipv4_connection", "ipv6_net", "ipv6_connection", "features", "slpf:rule_number"], help="Type of the target")
    parser.add_argument("--src_addr", help="Source address")
    parser.add_argument("--dst_addr", help="Destination address")
    parser.add_argument("--src_port", help="Source port (optional)")
    parser.add_argument("--dst_port", help="Destination port (optional)")
    parser.add_argument("--protocol", choices=["tcp", "udp", "icmp", "sctp"], help="Protocol (tcp, udp, icmp, sctp)")
    parser.add_argument("--network_address", help="Network address")
    parser.add_argument("--netmask", help="Netmask (optional)")
    parser.add_argument("--features", help="Comma-separated list of features to query")
    parser.add_argument("--rule_number", help="SLPF rule number for delete or update actions")
    parser.add_argument("--iptables_target", choices=["ACCEPT", "DROP"], help="Target for iptables (ACCEPT or DROP) for update action")

    # Parse arguments
    args = parser.parse_args()
    # Initialize command_arguments
    command_args = {}
    target = {}

    if args.action in ["allow", "deny"]:
        if args.target_type in ["ipv4_connection", "ipv6_connection"]:
            target[args.target_type] = {
                "src_addr": args.src_addr,
                "dst_addr": args.dst_addr,
                "src_port": args.src_port,
                "dst_port": args.dst_port,
                "protocol": args.protocol
            }
        elif args.target_type in ["ipv4_net", "ipv6_net"]:
            target[args.target_type] = {
                "network_address": args.network_address,
                "netmask": args.netmask
            }

    elif args.action == "query":
        target = {"features": [feat.strip() for feat in args.features.split(',')]}

    elif args.action == "delete":
        target = {"slpf:rule_number": args.rule_number}

    elif args.action == "update":
        if args.target_type in ["ipv4_connection", "ipv6_connection"]:
            target[args.target_type] = {
                "src_addr": args.src_addr,
                "dst_addr": args.dst_addr,
                "src_port": args.src_port,
                "dst_port": args.dst_port,
                "protocol": args.protocol
            }
        elif args.target_type in ["ipv4_net", "ipv6_net"]:
            target[args.target_type] = {
                "network_address": args.network_address,
                "netmask": args.netmask
            }
        target["slpf:rule_number"] = args.rule_number
        command_args["iptables_target"] = args.iptables_target

    command, target, command_args = create_openc2_command(args.action, target, command_args)

    if command:
        producer.sendcmd(command, consumers="OpenC2_Consumer")

    logger.info("Sending command: %s", cmd)
    resp = p.sendcmd(cmd)
    logger.info("Got response: %s", resp)


if __name__ == '__main__':
    main()
